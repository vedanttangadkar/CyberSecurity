# LP6 Practical Pack — STQA

This folder contains the five STQA practical programs from the teacher's option list.
It contains practical files only; viva notes are intentionally not included.

## Included programs

1. `Palindrome.java` — accepts a string and checks whether it is a palindrome (case-insensitive).
2. `LaunchWebsite.java` — opens SauceDemo, prints the page title, and closes the browser.
3. `LoginAutomation.java` — logs in to SauceDemo and verifies that the products page appears.
4. `AddToCartVerification.java` — adds Sauce Labs Backpack and verifies cart badge `1`.
5. `CheckoutAutomation.java` — logs in, adds the backpack, enters checkout details, finishes the order, and verifies the confirmation message.

## Requirements

- JDK 11 or newer
- Maven
- Google Chrome
- Internet connection for SauceDemo and first-time Maven dependency download

Selenium 4.27.0 is declared in `pom.xml`. Selenium Manager is used by Selenium 4 to obtain a compatible browser driver automatically in supported setups. A separate ChromeDriver download is normally not required.

## Run in Eclipse (Maven project)

1. Extract this ZIP.
2. Open Eclipse.
3. Select **File → Import → Maven → Existing Maven Projects**.
4. Select the `STQA` folder (the one containing `pom.xml`) and finish the import.
5. Wait for Maven dependencies to download.
6. Open `src/main/java/practicals`.
7. Right-click the required Java file → **Run As → Java Application**.

Run each program separately.

## Run from a terminal

Open a terminal in the `STQA` folder. Run the required program with the matching command below (Maven downloads the Exec plugin and Selenium dependencies when needed):

- Palindrome: `mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java -Dexec.mainClass=practicals.Palindrome`
- Launch website: `mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java -Dexec.mainClass=practicals.LaunchWebsite`
- Login: `mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java -Dexec.mainClass=practicals.LoginAutomation`
- Add to cart: `mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java -Dexec.mainClass=practicals.AddToCartVerification`
- Checkout: `mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java -Dexec.mainClass=practicals.CheckoutAutomation`

## Test credentials used by the teacher's practical

- Website: https://www.saucedemo.com/
- Username: `standard_user`
- Password: `secret_sauce`

Checkout test details are dummy values:
- First name: `Test`
- Last name: `User`
- Postal code: `411001`

## Important practical notes

- Keep the internet connection active for SauceDemo.
- Close other Chrome sessions if browser startup becomes problematic.
- If Chrome or Selenium Manager cannot start the browser, check Chrome installation, network/proxy restrictions, and Java/Maven setup.
- The palindrome program checks the complete entered string and ignores letter case; it does not remove spaces or punctuation.
- The Selenium programs use SauceDemo's standard test-site element IDs/classes and should be run against the supplied URL.
