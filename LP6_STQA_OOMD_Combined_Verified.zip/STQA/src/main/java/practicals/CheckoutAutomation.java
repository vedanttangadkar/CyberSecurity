package practicals;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CheckoutAutomation {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();

        try {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
            driver.get("https://www.saucedemo.com/");

            // Login
            driver.findElement(By.id("user-name")).sendKeys("standard_user");
            driver.findElement(By.id("password")).sendKeys("secret_sauce");
            driver.findElement(By.id("login-button")).click();

            new WebDriverWait(driver, Duration.ofSeconds(10))
                    .until(d -> d.findElement(By.id("inventory_container")).isDisplayed());

            // Add Sauce Labs Backpack and open cart
            driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
            driver.findElement(By.className("shopping_cart_link")).click();

            // Start checkout and enter customer details
            driver.findElement(By.id("checkout")).click();
            driver.findElement(By.id("first-name")).sendKeys("Test");
            driver.findElement(By.id("last-name")).sendKeys("User");
            driver.findElement(By.id("postal-code")).sendKeys("411001");
            driver.findElement(By.id("continue")).click();

            // Finish order
            driver.findElement(By.id("finish")).click();

            String confirmation = new WebDriverWait(driver, Duration.ofSeconds(10))
                    .until(d -> d.findElement(By.className("complete-header")).getText());

            if ("Thank you for your order!".equalsIgnoreCase(confirmation.trim())) {
                System.out.println("Checkout successful: " + confirmation);
            } else {
                System.out.println("Unexpected confirmation message: " + confirmation);
            }
        } finally {
            driver.quit();
        }
    }
}
