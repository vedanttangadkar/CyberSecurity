package practicals;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginAutomation {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();

        try {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
            driver.get("https://www.saucedemo.com/");

            driver.findElement(By.id("user-name")).sendKeys("standard_user");
            driver.findElement(By.id("password")).sendKeys("secret_sauce");
            driver.findElement(By.id("login-button")).click();

            new WebDriverWait(driver, Duration.ofSeconds(10))
                    .until(d -> d.findElement(By.id("inventory_container")).isDisplayed());

            if (driver.findElement(By.id("inventory_container")).isDisplayed()) {
                System.out.println("Login successful. Products page is displayed.");
            } else {
                System.out.println("Login failed.");
            }
        } finally {
            driver.quit();
        }
    }
}
