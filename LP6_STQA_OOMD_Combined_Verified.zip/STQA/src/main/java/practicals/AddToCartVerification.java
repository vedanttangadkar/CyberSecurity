package practicals;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddToCartVerification {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();

        try {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
            driver.get("https://www.saucedemo.com/");

            driver.findElement(By.id("user-name")).sendKeys("standard_user");
            driver.findElement(By.id("password")).sendKeys("secret_sauce");
            driver.findElement(By.id("login-button")).click();

            new WebDriverWait(driver, Duration.ofSeconds(10))
                    .until(d -> d.findElement(By.id("inventory_container")).isDisplayed());

            driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();

            new WebDriverWait(driver, Duration.ofSeconds(10))
                    .until(d -> d.findElement(By.className("shopping_cart_badge")).isDisplayed());

            String cartCount = driver.findElement(By.className("shopping_cart_badge")).getText();

            if ("1".equals(cartCount)) {
                System.out.println("Cart verification successful. Cart badge displays 1.");
            } else {
                System.out.println("Cart verification failed. Cart badge displays: " + cartCount);
            }
        } finally {
            driver.quit();
        }
    }
}
