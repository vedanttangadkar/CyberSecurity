import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

enum LoanState {
    CREATED, ACTIVE, OVERDUE, RETURNED, FINE_PENDING, CLOSED, CANCELLED
}

enum CopyState {
    AVAILABLE, RESERVED, BORROWED, UNDER_MAINTENANCE
}

enum MemberType {
    STUDENT, FACULTY
}

class Member {
    private final String memberId;
    private final MemberType type;
    private boolean valid;
    private int activeLoans;
    private final int borrowingLimit;

    public Member(String memberId, MemberType type, boolean valid, int borrowingLimit) {
        this.memberId = memberId;
        this.type = type;
        this.valid = valid;
        this.borrowingLimit = borrowingLimit;
        this.activeLoans = 0;
    }

    public boolean canBorrow() {
        return valid && activeLoans < borrowingLimit;
    }

    public void issueLoan() {
        if (!canBorrow()) {
            throw new IllegalStateException("Invalid membership or borrowing limit exceeded.");
        }
        activeLoans++;
    }

    public void closeLoan() {
        if (activeLoans > 0) {
            activeLoans--;
        }
    }

    public String getMemberId() {
        return memberId;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public MemberType getType() {
        return type;
    }
}

class BookCopy {
    private final String copyId;
    private CopyState state;
    private String reservedBy;

    public BookCopy(String copyId) {
        this.copyId = copyId;
        this.state = CopyState.AVAILABLE;
    }

    public boolean isAvailable() {
        return state == CopyState.AVAILABLE;
    }

    public void reserve(String memberId) {
        if (state != CopyState.AVAILABLE) {
            throw new IllegalStateException("Book copy is not available for reservation.");
        }
        state = CopyState.RESERVED;
        reservedBy = memberId;
    }

    public void issue(String memberId) {
        if (state == CopyState.RESERVED && !memberId.equals(reservedBy)) {
            throw new IllegalStateException("Book copy is reserved for another member.");
        }
        if (state != CopyState.AVAILABLE && state != CopyState.RESERVED) {
            throw new IllegalStateException("Book copy is unavailable.");
        }
        state = CopyState.BORROWED;
        reservedBy = null;
    }

    public void returnCopy() {
        if (state != CopyState.BORROWED) {
            throw new IllegalStateException("Cannot return a copy that is not borrowed.");
        }
        state = CopyState.AVAILABLE;
    }

    public CopyState getState() {
        return state;
    }

    public String getCopyId() {
        return copyId;
    }
}

class Loan {
    private final String loanId;
    private final Member member;
    private final BookCopy copy;
    private final LocalDate issueDate;
    private final LocalDate dueDate;
    private LoanState state;
    private double fine;

    public Loan(String loanId, Member member, BookCopy copy, LocalDate issueDate, int loanDays) {
        this.loanId = loanId;
        this.member = member;
        this.copy = copy;
        this.issueDate = issueDate;
        this.dueDate = issueDate.plusDays(loanDays);
        this.state = LoanState.CREATED;
        this.fine = 0.0;
    }

    public void issue() {
        if (state != LoanState.CREATED) {
            throw new IllegalStateException("Loan cannot be issued from state " + state);
        }
        if (!member.canBorrow()) {
            state = LoanState.CANCELLED;
            throw new IllegalStateException("Invalid membership or borrowing limit exceeded.");
        }
        copy.issue(member.getMemberId());
        member.issueLoan();
        state = LoanState.ACTIVE;
        System.out.println("Loan issued: " + loanId);
        System.out.println("Due date: " + dueDate);
    }

    public void checkOverdue(LocalDate currentDate) {
        if (state == LoanState.ACTIVE && currentDate.isAfter(dueDate)) {
            state = LoanState.OVERDUE;
            System.out.println("Loan is overdue: " + loanId);
        }
    }

    public void returnLoan(LocalDate returnDate) {
        if (state != LoanState.ACTIVE && state != LoanState.OVERDUE) {
            throw new IllegalStateException("Loan cannot be returned from state " + state);
        }
        long overdueDays = Math.max(0, ChronoUnit.DAYS.between(dueDate, returnDate));
        copy.returnCopy();
        member.closeLoan();

        if (overdueDays > 0) {
            fine = overdueDays * 10.0;
            state = LoanState.FINE_PENDING;
            System.out.println("Book returned late.");
            System.out.println("Fine due: Rs. " + fine);
        } else {
            state = LoanState.CLOSED;
            System.out.println("Book returned on time.");
        }
    }

    public void payFine(boolean paymentSuccessful) {
        if (state != LoanState.FINE_PENDING) {
            throw new IllegalStateException("No fine payment is pending.");
        }
        if (paymentSuccessful) {
            state = LoanState.CLOSED;
            fine = 0.0;
            System.out.println("Fine payment successful.");
        } else {
            System.out.println("Payment failed. Fine remains pending.");
        }
    }

    public LoanState getState() {
        return state;
    }

    public double getFine() {
        return fine;
    }
}

public class LibraryStateMachine {
    public static void main(String[] args) {
        System.out.println("TEST CASE 1: Successful issue and return");
        Member student = new Member("S101", MemberType.STUDENT, true, 3);
        BookCopy copy1 = new BookCopy("B101");
        Loan loan1 = new Loan("L101", student, copy1, LocalDate.of(2026, 10, 1), 14);
        loan1.issue();
        loan1.returnLoan(LocalDate.of(2026, 10, 10));
        System.out.println("Final state: " + loan1.getState());
        System.out.println();

        System.out.println("TEST CASE 2: Overdue return");
        Member student2 = new Member("S102", MemberType.STUDENT, true, 3);
        BookCopy copy2 = new BookCopy("B102");
        Loan loan2 = new Loan("L102", student2, copy2, LocalDate.of(2026, 9, 1), 7);
        loan2.issue();
        loan2.checkOverdue(LocalDate.of(2026, 9, 12));
        loan2.returnLoan(LocalDate.of(2026, 9, 12));
        System.out.println("Final state: " + loan2.getState());
        System.out.println("Fine: Rs. " + loan2.getFine());
        loan2.payFine(true);
        System.out.println("Final state: " + loan2.getState());
        System.out.println();

        System.out.println("TEST CASE 3: Invalid membership");
        Member student3 = new Member("S103", MemberType.STUDENT, false, 3);
        BookCopy copy3 = new BookCopy("B103");
        Loan loan3 = new Loan("L103", student3, copy3, LocalDate.of(2026, 10, 1), 14);
        try {
            loan3.issue();
        } catch (IllegalStateException e) {
            System.out.println("Issue rejected: " + e.getMessage());
            System.out.println("Loan state: " + loan3.getState());
        }
    }
}
