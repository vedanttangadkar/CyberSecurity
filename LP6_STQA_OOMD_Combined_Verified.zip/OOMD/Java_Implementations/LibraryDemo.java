import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

class Member {
    private final String memberId;
    private final boolean active;
    private final int borrowingLimit;
    private int activeLoans;

    Member(String memberId, boolean active, int borrowingLimit, int activeLoans) {
        this.memberId = memberId;
        this.active = active;
        this.borrowingLimit = borrowingLimit;
        this.activeLoans = activeLoans;
    }

    boolean canBorrow() {
        return active && activeLoans < borrowingLimit;
    }

    void addLoan() {
        if (!canBorrow()) {
            throw new IllegalStateException("Member cannot borrow");
        }
        activeLoans++;
    }

    String getMemberId() {
        return memberId;
    }
}

class BookCopy {
    private final String copyId;
    private boolean available;

    BookCopy(String copyId, boolean available) {
        this.copyId = copyId;
        this.available = available;
    }

    boolean isAvailable() {
        return available;
    }

    void markIssued() {
        if (!available) {
            throw new IllegalStateException("Copy is not available");
        }
        available = false;
    }

    void markAvailable() {
        available = true;
    }

    String getCopyId() {
        return copyId;
    }
}

class Loan {
    private final String loanId;
    private final LocalDate issueDate;
    private final LocalDate dueDate;
    private LocalDate returnDate;

    Loan(String loanId, LocalDate issueDate, LocalDate dueDate) {
        if (dueDate.isBefore(issueDate)) {
            throw new IllegalArgumentException("Invalid due date");
        }
        this.loanId = loanId;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
    }

    long overdueDays(LocalDate dateReturned) {
        return Math.max(0, ChronoUnit.DAYS.between(dueDate, dateReturned));
    }

    double calculateFine(LocalDate dateReturned, double dailyRate) {
        if (dailyRate < 0) {
            throw new IllegalArgumentException("Daily rate cannot be negative");
        }
        return overdueDays(dateReturned) * dailyRate;
    }

    void close(LocalDate dateReturned) {
        this.returnDate = dateReturned;
    }

    String getLoanId() {
        return loanId;
    }
}

public class LibraryDemo {
    public static void main(String[] args) {
        Member member = new Member("M101", true, 3, 1);
        BookCopy copy = new BookCopy("BC205", true);

        System.out.println("Member eligible: " + member.canBorrow());
        System.out.println("Copy available before issue: " + copy.isAvailable());

        if (member.canBorrow() && copy.isAvailable()) {
            member.addLoan();
            copy.markIssued();

            Loan loan = new Loan(
                "L9001",
                LocalDate.of(2026, 10, 1),
                LocalDate.of(2026, 10, 8)
            );

            LocalDate returned = LocalDate.of(2026, 10, 11);
            System.out.println("Loan created: " + loan.getLoanId());
            System.out.println("Overdue days: " + loan.overdueDays(returned));
            System.out.printf("Fine: %.2f%n", loan.calculateFine(returned, 5.0));

            loan.close(returned);
            copy.markAvailable();
            System.out.println("Copy available after return: " + copy.isAvailable());
        }
    }
}
