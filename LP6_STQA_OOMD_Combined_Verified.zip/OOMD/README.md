# LP6 OOMD Practical Pack

This pack contains practical materials for the five OOMD options, based on the five uploaded OOMD assignments. Viva questions/answers are intentionally excluded.

## Folder contents

### Diagrams
- `A1_Use_Case_Model.puml` — system boundary, actors, use cases, actor generalization, and the include relationships specified in Assignment 1.
- `A2_Activity_Model.puml` — Issue Book, Return Book, and Reserve Book workflows with Member, Librarian, and Library Management System swimlanes.
- `A3_Analysis_Class_Model.puml` — domain classes, attributes, operations, generalization, and multiplicities from Assignment 3.
- `A4_Sequence_Models.puml` — Search Catalog, Issue Book, Return Book, Reserve Book, and Pay Fine scenarios from Assignment 4.
- `A5_State_Machine_Models.puml` — Loan and BookCopy state machines with events, guards, and actions from Assignment 5.

The diagram files use PlantUML syntax. To render them, open them in a PlantUML-compatible editor/viewer. If the lab computer has PlantUML installed, use its export/render command. The `.puml` files are editable source, not screenshots.

### Java implementations
- `LibraryDemo.java` — Assignment 3 implementation of Member, BookCopy, and Loan.
- `LibraryStateMachine.java` — Assignment 5 implementation with enumerated states and three test cases.

## Run the Java programs

Requires JDK 11 or newer.

Open a terminal in `Java_Implementations` and run:

```bash
javac LibraryDemo.java
java LibraryDemo
```

For the state machine implementation:

```bash
javac LibraryStateMachine.java
java LibraryStateMachine
```

Each program is independent. Compile/run one at a time.

## Source-faithful notes to be aware of

1. Assignment 3's implementation demonstrates Member eligibility, BookCopy availability, Loan dates, overdue days, and fine calculation. It does not implement the entire class model.
2. Assignment 5's diagrams name Loan states `Active`, `Overdue`, `Returned`, and `Closed`, while its Java code additionally uses `CREATED`, `FINE_PENDING`, and `CANCELLED`. The code's BookCopy enum uses `AVAILABLE`, `RESERVED`, `BORROWED`, and `UNDER_MAINTENANCE`, whereas the diagram describes `Available`, `OnLoan`, `Reserved/Held`, and `Unavailable`. These are naming/model-detail differences in the supplied assignment; they have not been silently changed.
3. Assignment 5's Java implementation uses a 10.0 daily fine rate and a 14-day or 7-day loan duration in sample tests. The assignment says actual policy values are determined by library policy; these are sample values, not universal rules.
4. Assignment 5 describes a three-day reservation hold as an illustrative assumption.
5. Assignment 4's five sequence scenarios are included. The assignment describes the diagrams and interaction summaries; the `.puml` files turn those descriptions into editable UML sequence diagrams.

## Suggested practical order

1. A1 Use Case
2. A2 Activity
3. A3 Analysis Class
4. A4 Sequence
5. A5 State Machine

Viva preparation remains in the ChatGPT conversation and is not included here.
